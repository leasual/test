#include "others.h"


kal_int32 dsm_sms_custom_jtt_handle(kal_uint8 src, kal_uint8 *in, kal_int32 in_len);

